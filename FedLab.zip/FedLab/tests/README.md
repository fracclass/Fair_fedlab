# TESTS README

This folder contains: 

- test case scripts, like `test_*.py`
-  `data` folder: contains data files, which will be used in test. __DO NOT delete it!__

