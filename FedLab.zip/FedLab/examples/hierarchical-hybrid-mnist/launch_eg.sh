#!bin/bash

bash launch_topserver_eg.sh &

bash launch_cgroup1_eg.sh &

bash launch_cgroup2_eg.sh &

wait