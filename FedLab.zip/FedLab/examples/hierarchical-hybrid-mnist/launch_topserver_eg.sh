#!bin/bash

python top_server.py --ip 127.0.0.1 --port 3002 --world_size 3 &

wait