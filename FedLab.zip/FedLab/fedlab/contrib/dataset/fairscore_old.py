# Copyright 2021 Peng Cheng Laboratory (http://www.szpclab.com/) and FedLab Authors (smilelab.group)

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from torch.utils.data import Dataset, random_split, DataLoader
from .basic_dataset import FedDataset, BaseDataset
from ...utils.dataset.partition import BasicPartitioner, MNISTPartitioner


import pandas as pd
import os
import torch

from PIL import Image
import numpy as np



class Customer(Dataset):
    """Base dataset iterator"""

    def __init__(self, cls):
        df = pd.read_csv("../../../datasets/fairscore/customer.csv")
#        df['cat_all']=df.apply(lambda x:'%s%s%s%s%s%s%s' % (x['Cat == Cat_1'],x['Cat == Cat_2'],x['Cat == Cat_3'],x['Cat == Cat_4'],x['Cat == Cat_5'],x['Cat == Cat_6'],x['Cat == Cat_7']),axis=1)     
        self.x = df.iloc[:,0:25].values.astype(np.float32)
        if cls == '1':
            self.y = df['Cat == Cat_1'].values.astype(np.float32)
        elif cls == '2':
            self.y = df['Cat == Cat_2'].values.astype(np.float32)
        elif cls == '3':
            self.y = df['Cat == Cat_3'].values.astype(np.float32)
        elif cls == '4':
            self.y = df['Cat == Cat_4'].values.astype(np.float32)
        elif cls == '5':
            self.y = df['Cat == Cat_5'].values.astype(np.float32)
        elif cls == '6':
            self.y = df['Cat == Cat_6'].values.astype(np.float32)
        elif cls == '7':
            self.y = df['Cat == Cat_7'].values.astype(np.float32)
        elif cls == 'all':
            self.y = df.iloc[:,25:32].values.astype(np.float32)
        
    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return torch.tensor(self.x[index]), torch.tensor(self.y[index])

class Wine(Dataset):
    """Base dataset iterator"""

    def __init__(self, cls):
        df = pd.read_csv("../../../datasets/fairscore/wine.csv")
#        df['cat_all']=df.apply(lambda x:'%s%s%s' % (x['quality == low'],x['quality == medium'],x['quality == high']),axis=1)
        self.x = df.iloc[:,3:-1].values.astype(np.float32)
        if cls == '1':
            self.y = df['quality == low'].values.astype(np.float32)
        elif cls == '2':
            self.y = df['quality == medium'].values.astype(np.float32)
        elif cls == '3':
            self.y = df['quality == high'].values.astype(np.float32)
        elif cls == 'all':
            self.y = df.iloc[:,0:3].values.astype(np.float32)
        
    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return torch.tensor(self.x[index]), torch.tensor(self.y[index])

class Synthetic(Dataset):
    """Base dataset iterator"""

    def __init__(self, cls):
        df = pd.read_csv("../../../datasets/fairscore/synthetic.csv")
#        df['cat_all']=df.apply(lambda x:'%s%s%s' % (x['L1'],x['L2'],x['L3']),axis=1)        
        self.x = df.iloc[:,0:6].values.astype(np.float32)
        if cls == '1':
            self.y = df['L1'].values.astype(np.float32)
        elif cls == '2':
            self.y = df['L2'].values.astype(np.float32)
        elif cls == '3':
            self.y = df['L3'].values.astype(np.float32)
        elif cls == 'all':
            self.y = df.iloc[:,6:-1].values.astype(np.float32)
            

    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return torch.tensor(self.x[index]), torch.tensor(self.y[index])

class SyntheticFed(FedDataset):
    """:class:`FedDataset` with partitioning preprocess. For detailed partitioning, please
    check `Federated Dataset and DataPartitioner <https://fedlab.readthedocs.io/en/master/tutorials/dataset_partition.html>`_.

    
    Args:
        root (str): Path to download raw dataset.
        path (str): Path to save partitioned subdataset.
        num_clients (int): Number of clients.
        download (bool): Whether to download the raw dataset.
        preprocess (bool): Whether to preprocess the dataset.
        partition (str, optional): Partition name. Only supports ``"noniid-#label"``, ``"noniid-labeldir"``, ``"unbalance"`` and ``"iid"`` partition schemes.
        dir_alpha (float, optional): Dirichlet distribution parameter for non-iid partition. Only works if ``partition="dirichlet"``. Default as ``None``.
        verbose (bool, optional): Whether to print partition process. Default as ``True``.
        seed (int, optional): Random seed. Default as ``None``.
        transform (callable, optional): A function/transform that takes in an PIL image and returns a transformed version.
        target_transform (callable, optional): A function/transform that takes in the target and transforms it.
    """
    def __init__(self,
                 root,
                 path,
                 num_clients,
                 download=True,
                 preprocess=False,
                 partition="iid",
                 dir_alpha=None,
                 verbose=True,
                 seed=None,
                 transform=None,
                 target_transform=None) -> None:

        self.path = path
        self.num_clients = num_clients
        self.transform = transform
        self.targt_transform = target_transform

        if preprocess:
            self.preprocess(partition=partition,
                            dir_alpha=dir_alpha,
                            verbose=verbose,
                            seed=seed,
                            download=download,
                            transform=transform,
                            target_transform=target_transform)

    def preprocess(self,
                   partition="iid",
                   dir_alpha=None,
                   verbose=True,
                   seed=None,
                   download=True,
                   transform=None,
                   target_transform=None):
        """Perform FL partition on the dataset, and save each subset for each client into ``data{cid}.pkl`` file.

        For details of partition schemes, please check `Federated Dataset and DataPartitioner <https://fedlab.readthedocs.io/en/master/tutorials/dataset_partition.html>`_.
        """

        if os.path.exists(self.path) is not True:
            os.mkdir(self.path)
            os.mkdir(os.path.join(self.path, "train"))
            os.mkdir(os.path.join(self.path, "var"))
            os.mkdir(os.path.join(self.path, "test"))


        df = pd.read_csv("../../../datasets/fairscore/synthetic.csv")    
        self.features = df.iloc[:,0:6].values.astype(np.float32)
        if cls == '1':
            self.targets = df['L1'].values.astype(np.float32)
        elif cls == '2':
            self.targets = df['L2'].values.astype(np.float32)
        elif cls == '3':
            self.targets = df['L3'].values.astype(np.float32)
        elif cls == 'all':
            self.targets = df.iloc[:,6:-1].values.astype(np.float32)

        torch_dataset = (torch.tensor(self.features), torch.tensor(self.targets))
        train_len = int(0.7*len(torch_dataset))
        valid_len = len(torch_dataset) - train_len

        trainset, testset = random_split(torch_dataset, [train_len, valid_len])

        #train_dataloader = DataLoader(trainset, batch_size=64, shuffle=True)
        #test_dataloader = DataLoader(testset, batch_size=64, shuffle=True)


        partitioner = BasicPartitioner(trainset.targets,
                                        self.num_clients,
                                        partition=partition,
                                        dir_alpha=dir_alpha,
                                        verbose=verbose,
                                        seed=seed)

        # partition
        subsets = {
            cid: Subset(trainset,
                        partitioner.client_dict[cid],
                        transform=transform,
                        target_transform=target_transform)
            for cid in range(self.num_clients)
        }
        for cid in subsets:
            torch.save(
                subsets[cid],
                os.path.join(self.path, "train", "data{}.pkl".format(cid)))

    def get_dataset(self, cid, type="train"):
        """Load subdataset for client with client ID ``cid`` from local file.

        Args:
             cid (int): client id
             type (str, optional): Dataset type, can be ``"train"``, ``"val"`` or ``"test"``. Default as ``"train"``.

        Returns:
            Dataset
        """
        dataset = torch.load(
            os.path.join(self.path, type, "data{}.pkl".format(cid)))
        return dataset

    def get_dataloader(self, cid, batch_size=None, type="train"):
        """Return dataload for client with client ID ``cid``.

        Args:
            cid (int): client id
            batch_size (int, optional): batch size in DataLoader.
            type (str, optional): Dataset type, can be ``"train"``, ``"val"`` or ``"test"``. Default as ``"train"``.
        """
        dataset = self.get_dataset(cid, type)
        batch_size = len(dataset) if batch_size is None else batch_size
        data_loader = DataLoader(dataset, batch_size=batch_size)
        return data_loader


    def __init__(self, cls):
        df = pd.read_csv("../../../datasets/fairscore/synthetic.csv")
#        df['cat_all']=df.apply(lambda x:'%s%s%s' % (x['L1'],x['L2'],x['L3']),axis=1)        
        self.x = df.iloc[:,0:6].values.astype(np.float32)
        if cls == '1':
            self.y = df['L1'].values.astype(np.float32)
        elif cls == '2':
            self.y = df['L2'].values.astype(np.float32)
        elif cls == '3':
            self.y = df['L3'].values.astype(np.float32)
        elif cls == 'all':
            self.y = df.iloc[:,6:-1].values.astype(np.float32)
            
    def __len__(self):
        return len(self.y)

    def __getitem__(self, index):
        return torch.tensor(self.x[index]), torch.tensor(self.y[index])



class PathologicalMNIST(FedDataset):
    """The partition stratigy in FedAvg. See http://proceedings.mlr.press/v54/mcmahan17a?ref=https://githubhelp.com

        Args:
            root (str): Path to download raw dataset.
            path (str): Path to save partitioned subdataset.
            num_clients (int): Number of clients.
            shards (int, optional): Sort the dataset by the label, and uniformly partition them into shards. Then 
            download (bool, optional): Download. Defaults to True.
        """
    def __init__(self, root, path, num_clients=100, shards=200, download=True, preprocess=False) -> None:
        self.root = os.path.expanduser(root)
        self.path = path
        self.num_clients = num_clients
        self.shards = shards
        if preprocess:
            self.preprocess(num_clients, shards, download)

    def preprocess(self, download=True):
        # self.num_clients = num_clients
        # self.shards = shards
        self.download = download

        if os.path.exists(self.path) is not True:
            os.mkdir(self.path)
        
        if os.path.exists(os.path.join(self.path, "train")) is not True:
            os.mkdir(os.path.join(self.path, "train"))
            os.mkdir(os.path.join(self.path, "var"))
            os.mkdir(os.path.join(self.path, "test"))
            
        # train
        mnist = torchvision.datasets.MNIST(self.root, train=True, download=self.download,
                                           transform=transforms.ToTensor())
        data_indices = noniid_slicing(mnist, self.num_clients, self.shards)

        samples, labels = [], []
        for x, y in mnist:
            samples.append(x)
            labels.append(y)
        for id, indices in data_indices.items():
            data, label = [], []
            for idx in indices:
                x, y = samples[idx], labels[idx]
                data.append(x)
                label.append(y)
            dataset = BaseDataset(data, label)
            torch.save(dataset, os.path.join(self.path, "train", "data{}.pkl".format(id)))

    def get_dataset(self, id, type="train"):
        """Load subdataset for client with client ID ``cid`` from local file.

        Args:
            cid (int): client id
            type (str, optional): Dataset type, can be ``"train"``, ``"val"`` or ``"test"``. Default as ``"train"``.

        Returns:
            Dataset
        """
        dataset = torch.load(os.path.join(self.path, type, "data{}.pkl".format(id)))
        return dataset

    def get_dataloader(self, id, batch_size=None, type="train"):
        """Return dataload for client with client ID ``cid``.

        Args:
            cid (int): client id
            batch_size (int, optional): batch size in DataLoader.
            type (str, optional): Dataset type, can be ``"train"``, ``"val"`` or ``"test"``. Default as ``"train"``.
        """
        dataset = self.get_dataset(id, type)
        batch_size = len(dataset) if batch_size is None else batch_size
        data_loader = DataLoader(dataset, batch_size=batch_size)
        return data_loader
    

class Subset(Dataset):
    """For data subset with different augmentation for different client.

    Args:
        dataset (Dataset): The whole Dataset
        indices (List[int]): Indices of sub-dataset to achieve from ``dataset``.
        transform (callable, optional): A function/transform that takes in an PIL image and returns a transformed version.
        target_transform (callable, optional): A function/transform that takes in the target and transforms it.
    """

    def __init__(self, dataset, indices, transform=None, target_transform=None):
        self.data = []
        for idx in indices:
            self.data.append(dataset.data[idx])

        if not isinstance(dataset.targets, np.ndarray):
            dataset.targets = np.array(dataset.targets)
            
        self.targets = dataset.targets[indices].tolist()

        self.transform = transform
        self.target_transform = target_transform

    def __getitem__(self, index):
        """Get item

        Args:
            index (int): index

        Returns:
            (image, target) where target is index of the target class.
        """
        img, label = self.data[index], self.targets[index]

        if self.transform is not None:
            img = self.transform(img)
        if self.target_transform is not None:
            label = self.target_transform(label)

        return img, label

    def __len__(self):
        return len(self.targets)

class CIFARSubset(Subset):
    """For data subset with different augmentation for different client.

    Args:
        dataset (Dataset): The whole Dataset
        indices (List[int]): Indices of sub-dataset to achieve from ``dataset``.
        transform (callable, optional): A function/transform that takes in an PIL image and returns a transformed version.
        target_transform (callable, optional): A function/transform that takes in the target and transforms it.
    """
    def __init__(self,
                 dataset,
                 indices,
                 transform=None,
                 target_transform=None,
                 to_image=True):
        self.data = []
        for idx in indices:
            if to_image:
                self.data.append(Image.fromarray(dataset.data[idx]))
        if not isinstance(dataset.targets, np.ndarray):
            dataset.targets = np.array(dataset.targets)
        self.targets = dataset.targets[indices].tolist()
        self.transform = transform
        self.target_transform = target_transform


class FedDataset(object):
    def __init__(self) -> None:
        self.num = None  # the number of dataset indexed from 0 to num-1.
        self.root = None  # the raw dataset.
        self.path = None  # path to save the partitioned datasets.

    def preprocess(self):
        """Define the dataset partition process"""
        if os.path.exists(self.path) is not True:
            os.mkdir(self.path)
            os.mkdir(os.path.join(self.path, "train"))
            os.mkdir(os.path.join(self.path, "var"))
            os.mkdir(os.path.join(self.path, "test"))

    def get_dataset(self, id, type="train"):
        """Get dataset class

        Args:
            id (int): Client ID for the partial dataset to achieve.
            type (str, optional): Type of dataset, can be chosen from ``["train", "val", "test"]``. Defaults as ``"train"``.

        Raises:
            NotImplementedError
        """
        raise NotImplementedError()

    def get_dataloader(self, id, batch_size, type="train"):
        """Get data loader"""
        raise NotImplementedError()

    def __len__(self):
        return self.num
