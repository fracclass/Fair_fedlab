# Copyright 2021 Peng Cheng Laboratory (http://www.szpclab.com/) and FedLab Authors (smilelab.group)

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
from sklearn.datasets import load_svmlight_file
import random
import os
import pandas as pd
import torch
from urllib.request import urlretrieve

from .basic_dataset import FedDataset, BaseDataset
from torch.utils.data import Dataset
from torch.utils.data import DataLoader

from ...utils.dataset.functional import noniid_slicing, random_slicing



class FairscoreSynthetic(Dataset):
    """`FairscoreSynthetic <https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#a9a>`_ dataset from `LIBSVM Data <https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/>`_.

    Args:
        root (str): Root directory of raw dataset to download if ``download`` is set to ``True``.
        train (bool, optional): If True, creates dataset from training set, otherwise creates from test set.
        transform (callable, optional): A function/transform that takes in an PIL image and returns a transformed version. Default as ``None``.
        target_transform (callable, optional): A function/transform that takes in the target and transforms it. Default as ``None``.
        download (bool, optional): If true, downloads the dataset from the internet and puts it in root directory. If dataset is already downloaded, it is not downloaded again.

    """
    num_classes = 3
    num_features = 6

    def __init__(self, file_path, train=True,
                 transform=None,
                 target_transform=None,
                 download=False):
        self.file_name = file_path        
        self.train = train
        self.transform = transform
        self.target_transform = target_transform

        if not self._local_file_existence():
            raise RuntimeError(
                f"Fairscore synthetic file not found. Check path {self.file_name}")

        # now load from source file
        df = pd.read_csv(self.file_name)    
        df['targets'] = np.where(
            df['L1'] == 1, 0, np.where(
            df['L2'] == 0 , 1, 2)) 
        
        self.data = df.iloc[:,0:6].values.astype(np.float32)
        self.targets = df['targets'].values.astype(np.int32)

        torch_dataset = {'data':torch.tensor(self.data), 'targets': torch.tensor(self.targets)}

        train_len = int(0.7*len(self.data))

        print(f"Local file {self.file_name} loaded.")
        if self.train:
            self.data, self.targets = torch_dataset['data'][0:train_len,:], torch_dataset['targets'][0:train_len]
        else:
            self.data, self.targets = torch_dataset['data'][train_len:,:], torch_dataset['targets'][train_len:]
            

    def _local_file_existence(self):
        return os.path.exists(self.file_name)

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (features, target) where target is index of the target class.
        """
        data, label = self.data[index,:], self.targets[index]

        return data, label

    def __len__(self):
        return len(self.targets)

    def extra_repr(self) -> str:
        return "Split: {}".format("Train" if self.train is True else "Test")


class FedFairscoreSynthetic(FedDataset):
    """`FairscoreSynthetic <https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#a9a>`_ dataset from `LIBSVM Data <https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/>`_.

    Args:
        root (str): Root directory of raw dataset to download if ``download`` is set to ``True``.
        train (bool, optional): If True, creates dataset from training set, otherwise creates from test set.
        transform (callable, optional): A function/transform that takes in an PIL image and returns a transformed version. Default as ``None``.
        target_transform (callable, optional): A function/transform that takes in the target and transforms it. Default as ``None``.
        download (bool, optional): If true, downloads the dataset from the internet and puts it in root directory. If dataset is already downloaded, it is not downloaded again.

    """
    def __init__(
        self, root, path, num_clients=100, shards=200, download=False, preprocess=False
    ) -> None:
        self.file_name = root
        self.path = path
        self.num_clients = num_clients
        self.shards = shards
        if preprocess:
            self.preprocess(download)

    def preprocess(self, download=True):
        # self.num_clients = num_clients
        # self.shards = shards
        self.download = download

        if os.path.exists(self.path) is not True:
            os.mkdir(self.path)

        if os.path.exists(os.path.join(self.path, "train")) is not True:
            os.mkdir(os.path.join(self.path, "train"))
            os.mkdir(os.path.join(self.path, "var"))
            os.mkdir(os.path.join(self.path, "test"))

        # now load from data
        trainset = FairscoreSynthetic(file_path=self.file_name, train=True, download=False)

#        df = pd.read_csv(self.file_name)    
#        df['targets'] = np.where(
#            df['L1'] == 1, 0, np.where(
#            df['L2'] == 0 , 1, 2)) 
        
#        self.data = df.iloc[:,0:6].values.astype(np.float32)
#        self.targets = df['targets'].values.astype(np.int32)
#        train_len = int(0.7*len(self.data))

#        trainset = {'data':torch.tensor(self.data[0:train_len,:]), 'targets': torch.tensor(self.targets[0:train_len])}
#        testset = {'data':torch.tensor(self.data[train_len:,:]), 'targets': torch.tensor(self.targets[train_len:])}

        data_indices = noniid_slicing(trainset, self.num_clients, self.shards)
            
        samples, labels = [], []

        for x, y in trainset:
            samples.append(x)
            labels.append(y)
                
        for id, indices in data_indices.items():
            data, label = [], []
            for idx in indices:
                x, y = samples[idx], labels[idx]
                data.append(x)
                label.append(y)
            dataset = BaseDataset(data, label)
            torch.save(
                dataset, os.path.join(self.path, "train", "data{}.pkl".format(id))
            )

    def get_dataset(self, cid, type="train"):
        """Load subdataset for client with client ID ``cid`` from local file.

        Args:
             cid (int): client id
             type (str, optional): Dataset type, can be ``"train"``, ``"val"`` or ``"test"``. Default as ``"train"``.

        Returns:
            Dataset
        """
        dataset = torch.load(
            os.path.join(self.path, type, "data{}.pkl".format(cid)))
        return dataset

    def get_dataloader(self, cid, batch_size=None, type="train"):
        """Return dataload for client with client ID ``cid``.

        Args:
            cid (int): client id
            batch_size (int, optional): batch size in DataLoader.
            type (str, optional): Dataset type, can be ``"train"``, ``"val"`` or ``"test"``. Default as ``"train"``.
        """
        dataset = self.get_dataset(cid, type)
        batch_size = len(dataset) if batch_size is None else batch_size
        data_loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
        return data_loader

class FairscoreWine(Dataset):
    """`FairscoreSynthetic <https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/binary.html#a9a>`_ dataset from `LIBSVM Data <https://www.csie.ntu.edu.tw/~cjlin/libsvmtools/datasets/>`_.

    Args:
        root (str): Root directory of raw dataset to download if ``download`` is set to ``True``.
        train (bool, optional): If True, creates dataset from training set, otherwise creates from test set.
        transform (callable, optional): A function/transform that takes in an PIL image and returns a transformed version. Default as ``None``.
        target_transform (callable, optional): A function/transform that takes in the target and transforms it. Default as ``None``.
        download (bool, optional): If true, downloads the dataset from the internet and puts it in root directory. If dataset is already downloaded, it is not downloaded again.

    """
    #file_name = "../../datasets/fairscore/wine.csv"
    num_classes = 3
    num_features = 25

    def __init__(self, file_path, train=True,
                 transform=None,
                 target_transform=None,
                 download=False):
        self.file_name = file_path
        self.train = train
        self.transform = transform
        self.target_transform = target_transform

        if not self._local_file_existence():
            raise RuntimeError(
                f"Fairscore synthetic file not found. Check path {self.file_name}")

        # now load from source file
        print(f"current directory {os.getcwd()}")
        df = pd.read_csv(self.file_name)    
        df['targets'] = np.where(
            df['quality == low'] == 1, 0, np.where(
            df['quality == medium'] == 0 , 1, 2)) 
        
        self.data = df.iloc[:,0:6].values.astype(np.float32)
        self.targets = df['targets'].values.astype(np.int32)

        torch_dataset = {'data':torch.tensor(self.data), 'targets': torch.tensor(self.targets)}

        train_len = int(0.7*len(self.data))
        valid_len = len(self.data) - train_len

        print(f"Local file {self.file_name} loaded.")
        if self.train:
            self.data, self.targets = torch_dataset['data'][0:train_len,:], torch_dataset['targets'][0:train_len]
        else:
            self.data, self.targets = torch_dataset['data'][train_len:,:], torch_dataset['targets'][train_len:]
            

    def _local_file_existence(self):
        return os.path.exists(self.file_name)

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (features, target) where target is index of the target class.
        """
        data, label = self.data[index], self.targets[index]

        return data, label

    def __len__(self):
        return len(self.targets)

    def extra_repr(self) -> str:
        return "Split: {}".format("Train" if self.train is True else "Test")
