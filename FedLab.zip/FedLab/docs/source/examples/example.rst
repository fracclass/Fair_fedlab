.. _example:

********
Examples
********

.. toctree::
   :hidden:

   quick_start
   leaf_usage



.. card:: Quick Start
    :link: quickstart
    :link-type: ref
    :class-card: sd-rounded-2 sd-border-1

.. card:: PyTorch version of LEAF
    :link: leaf
    :link-type: ref
    :class-card: sd-rounded-2 sd-border-1

